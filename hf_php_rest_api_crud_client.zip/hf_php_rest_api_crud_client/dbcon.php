<?php

$con = mysqli_connect("localhost", "root", "", "hf_php_rest_api_crud");

if(!$con)
{
    die('Connection Failed' . mysqli_connect_error());
}



?>